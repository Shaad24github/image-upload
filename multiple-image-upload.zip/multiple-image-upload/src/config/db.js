module.exports = {
    url: "mongodb://127.0.0.1:27017/micron_files_db",
    database: "micron_files_db",
    imgBucket: "photos",
};